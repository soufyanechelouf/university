-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 02 Mai 2017 à 13:40
-- Version du serveur :  10.1.21-MariaDB
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `informatique`
--

-- --------------------------------------------------------

--
-- Structure de la table `biographie`
--

CREATE TABLE `biographie` (
  `BioId` int(11) NOT NULL COMMENT 'Biographie Id',
  `FirstName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'FirstName of teaher',
  `LastName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'LasntName of teacher',
  `BioUser` int(11) NOT NULL COMMENT 'Teacher Boigraphie',
  `AboutMe` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'About Me',
  `Skills` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Skills',
  `Biographie` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Biographie ',
  `Adresse` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Adresse',
  `Web` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Site Web',
  `Email` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Emal',
  `Facebook` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Facebook',
  `LinkedIn` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Linked In',
  `Youtube` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Youtube',
  `Twitter` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Twitter',
  `Phone` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Phone',
  `Image` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Image of Teacher',
  `Public` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Allow view'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `biographie`
--

INSERT INTO `biographie` (`BioId`, `FirstName`, `LastName`, `BioUser`, `AboutMe`, `Skills`, `Biographie`, `Adresse`, `Web`, `Email`, `Facebook`, `LinkedIn`, `Youtube`, `Twitter`, `Phone`, `Image`, `Public`) VALUES
(1, '', '', 42, '                                  Salam You Are Welcome Salam You Are WelcomeSalam You Are WelcomeSalam You Are WelcomeSalam You Are WelcomeSalam You Are Welcome                                                                                              ', '                                                                    my skills                                                                                                                                                                                  ', '                                                                    my biographie                                                                ', 'tlemcen', 'http://www.google.fr', 'a.mous@esi-sba.dz', 'https://www.facebook.com/', 'https://www.facebook.com/', 'https://www.facebook.com/', 'https://www.facebook.com/', '022', 'images/laptop.jpg', 1),
(2, 'nadir', 'nadir', 19, '                                  Salam You Are Welcome Salam You Are Welcome Salam You Are Welcome Salam You Are Welcome Salam You Are Welcome Salam You Are Welcome Salam You Are Welcome                                                                    ', '                                                                                                      \r\n                                                                                                ', '                                                                                                      \r\n                                                                                                ', '', '', '', '', '', '', '', '', 'images/study.jpg', 1),
(3, 'LOKBANI', 'Chouaib', 17, 'Salam You Are Welcome Salam You Are WelcomeSalam You Are WelcomeSalam You Are Welcome                                 \r\n                                ', '                                  \r\n                                ', '                                  \r\n                                ', '', '', '', '', '', '', '', '', 'images/web1.jpg', 1),
(4, 'DERGHAM', 'LAHCEN', 38, 'WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELCOME WELC', '                                  \r\n                                ', '                                  \r\n                                ', '', '', '', '', '', '', '', '', 'images/design.jpg', 1);

-- --------------------------------------------------------

--
-- Structure de la table `classes`
--

CREATE TABLE `classes` (
  `ClasseId` int(11) NOT NULL COMMENT 'To Identifier',
  `Name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `A_University` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `classes`
--

INSERT INTO `classes` (`ClasseId`, `Name`, `A_University`) VALUES
(1, '1 Année', '2016/2017'),
(2, '2 Année', '2016/2017'),
(3, '3 Année', '2016/2017'),
(4, '4 Année', '2016/2017'),
(5, '5 Année', '2016/2017');

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE `events` (
  `EventId` int(11) NOT NULL COMMENT 'To Identifier Events',
  `Title` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'The Title of Events',
  `Description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'The Description of Events',
  `Image` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Path of the Picture',
  `Adresse` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Addresse',
  `Date` datetime NOT NULL COMMENT 'Start Date',
  `EndDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `events`
--

INSERT INTO `events` (`EventId`, `Title`, `Description`, `Image`, `Adresse`, `Date`, `EndDate`) VALUES
(2, 'Alphpa Bit', 'LEAD Alphpa Bit  Alphpa Bit Alphpa Bit Alphpa Bit Alphpa Bit Alphpa Bit Alphpa Bit Alphpa Bit Alphpa Bit', 'images/contact.jpg', 'Biliothéque Central', '2019-01-03 03:01:00', '0000-00-00 00:00:00'),
(3, 'alpha bit', 'lead', 'images/5.jpg', 'hananan', '2017-04-29 06:10:00', '0000-00-00 00:00:00'),
(5, 'gfgf', 'fgffgfg', 'images/web1.jpg', 'gfgfgfgfg', '2017-04-07 01:01:00', '2017-04-07 00:00:00'),
(6, 'Lead', 'alpha bit', 'images/librairie.jpg', 'this si alpha bit club', '2017-04-06 01:02:00', '2019-01-03 01:01:00'),
(7, 'new', 'new', 'images/laptop.jpg', 'new', '2017-04-22 00:00:00', '2017-04-16 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `news`
--

CREATE TABLE `news` (
  `NewsId` int(11) NOT NULL COMMENT 'To Identifier news',
  `Title` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'The Title of News',
  `Description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'The Description of News',
  `Details` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Details of News',
  `Type` varchar(255) NOT NULL COMMENT 'Image of News',
  `InSlider` tinyint(1) NOT NULL DEFAULT '0',
  `PostedBy` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Ajouter Par',
  `Image` varchar(255) NOT NULL COMMENT 'Image of Article',
  `Date` datetime NOT NULL COMMENT 'The Date'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `news`
--

INSERT INTO `news` (`NewsId`, `Title`, `Description`, `Details`, `Type`, `InSlider`, `PostedBy`, `Image`, `Date`) VALUES
(8, 'chouaib Lokbani', 'Weclcome In My Site', 'salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam salam          ', 'Club', 1, 'wassim', 'images/3.jpg', '2017-04-21 01:17:15'),
(9, 'chouaib Lokbani', ' fdfd fdfd fdfd fdfd fdfd fdfd fdfd fdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ffdfd ff', 'fdfdff fdf fdfdf fdfdf fd fdf fdfdf fd fdf fdf df dfd ffdfdff fdf fdfdf fdfdf fd fdf fdfdf fd fdf fdf df dfd ffdfdff fdf fdfdf fdfdf fd fdf fdfdf fd fdf fdf df dfd ffdfdff fdf fdfdf fdfdf fd fdf fdfdf fd fdf fdf df dfd ffdfdff fdf fdfdf fdfdf fd fdf fdfdf', 'Pedagogique', 0, 'chouaib', 'images/librairie.jpg', '2017-04-22 17:42:11'),
(10, 'chouaib Lokbani', 'salam salam salam salam salam salam salam  salam salam salam salam salam salam salam salam s', 'salam ', 'Club', 0, 'chouaib', 'images/boy.jpg', '2017-04-24 18:10:36'),
(11, 'Welcome In Our World', 'You are welcome in our World', '', 'Pedagogique', 1, 'Wassim', 'images/header.jpg', '2017-05-01 12:30:03');

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `NotId` int(11) NOT NULL COMMENT 'To Identifier Notifications',
  `Type` varchar(255) NOT NULL COMMENT 'Type of Notification',
  `Subject` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Subject of Notifacation',
  `NotDestina` int(11) NOT NULL COMMENT 'Notification Destinaton',
  `NotGroupId` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Notification Group Id',
  `Date` datetime NOT NULL COMMENT 'Date of Notification'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `notifications`
--

INSERT INTO `notifications` (`NotId`, `Type`, `Subject`, `NotDestina`, `NotGroupId`, `Date`) VALUES
(3, 'Etude', 'le concours d\'accès au cycle superieurs aura lieu le 19 juin 2017', 1, 'students', '2017-04-27 23:12:50'),
(4, 'Etude', 'Vous Avez Un test le mercredi prochain En Probabilité ', 2, 'students', '2017-04-29 14:31:06'),
(5, 'Etude', 'Une nouvelle formation de réseau est disponible ', 2, 'teahcers', '2017-04-29 15:00:22'),
(6, 'Etude', 'Le Concours d\'accée au lieu le 19 juin 2017', 2, 'students', '2017-04-29 15:01:45'),
(7, 'Felicitation ', 'Vous Avez Admis en troisième Année', 2, 'students', '2017-04-29 19:00:14');

-- --------------------------------------------------------

--
-- Structure de la table `study`
--

CREATE TABLE `study` (
  `StudyId` int(11) NOT NULL COMMENT 'To Identifier Study',
  `Name` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Name of its',
  `Description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Description',
  `Type` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'the Type',
  `Level` int(11) NOT NULL,
  `Module` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Year` varchar(255) CHARACTER SET utf8 NOT NULL,
  `File` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Path of file',
  `Date` datetime NOT NULL COMMENT 'Adding Time'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `study`
--

INSERT INTO `study` (`StudyId`, `Name`, `Description`, `Type`, `Level`, `Module`, `Year`, `File`, `Date`) VALUES
(9, 'chouaib', 'fgfgfg', 'Exam', 1, 'Electrinque', '2016/2017', 'files/deliberat_2CPI.pdf', '2017-04-20 23:19:14'),
(14, 'cours', 'bvbvb', 'Cour', 1, 'Assembleur', 'vbvbvb', 'files/esi-program_cpi.pdf', '2017-04-20 23:41:59'),
(15, 'cours', 'vbvbvb', 'Cour', 1, 'Electricité', 'bvbvbv', 'files/admin_files_esi-program_cpi.pdf', '2017-04-20 23:42:28'),
(16, 'TDs', 'cvcvcxv', 'TD', 1, 'TEE', 'cvcvc', 'files/deliberat_2CPI.pdf', '2017-04-20 23:52:35'),
(17, 'Analuse', 'thtis is cours ', 'TD', 2, 'Analyse', '2016/2017', 'files/délibération_1CPI.pdf', '2017-04-30 13:08:00'),
(18, 'Analyse ', 'this is exam', 'Exam', 1, 'Analyse', '2016/2017', 'files/esi-program_cpi.pdf', '2017-05-01 07:10:55'),
(19, 'analyse 2', 'this is exam for analyse 2 student of first level', 'Exam', 1, 'Analyse', '2016/2017', 'files/deliberat_2CPI.pdf', '2017-05-02 10:20:41');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `UserId` int(11) NOT NULL COMMENT 'To Identifier users',
  `Email` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Email to login',
  `Password` varchar(255) NOT NULL COMMENT 'Password to login',
  `Hash` varchar(255) NOT NULL COMMENT 'Redirection',
  `FirstName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'FirstName of User',
  `LastName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'LastName of User',
  `Grade` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'Grade of teacher',
  `Level` int(11) NOT NULL COMMENT 'Level of Student',
  `Date` datetime NOT NULL,
  `RegStatus` tinyint(1) NOT NULL DEFAULT '0',
  `GroupId` smallint(6) DEFAULT '0' COMMENT 'Group of users',
  `Approved` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`UserId`, `Email`, `Password`, `Hash`, `FirstName`, `LastName`, `Grade`, `Level`, `Date`, `RegStatus`, `GroupId`, `Approved`) VALUES
(1, 'c.lokbani@esi-sba.dz', '1e70d493f036636c9af282e53b4513d28c018e62', '', 'Chouaib', 'LOKBANI', '', 1, '2017-04-15 11:56:32', 1, 0, 0),
(17, 'z.mekri@esi-sba.dz', 'fd51c3bfb515bb77a42a258672841b9dbeb7ccff', '', 'LOKBANI', 'Chouaib', 'MASTER', 2, '2017-04-15 19:41:47', 1, 1, 0),
(19, 'c@live.com', 'e50fdf8d4ed5d53eb161ccd886f777d22b72cda5', '', 'nadir', 'nadir', 'master', 2, '2017-04-16 22:53:37', 1, 1, 0),
(35, 'w.lokbani@esi-sba.dz', '1e70d493f036636c9af282e53b4513d28c018e62', '', 'LOKBANI', 'WASSIM', '', 1, '2017-04-16 23:23:11', 1, 0, 0),
(38, 'a.malki@esi-sba.dz', '9426e2eba89cc33f00c5e7c3040255d65b1588e9', '', 'DERGHAM', 'LAHCEN', 'DOCTART', 2, '2017-04-18 13:00:56', 1, 1, 0),
(39, 'i.saidi@esi-sba.dz', '3403855029fb83b0d063ce20664098ef653d1040', '', 'SAIDI', 'IMENE', 'DOCTORAT', 2, '2017-04-18 19:17:22', 1, 1, 0),
(40, 't.lokbani@esi-sba.dz', '243fad2125b703b6e06c163de9bc1f108deb8225', '', 'LOKBANI', 'TARIK', '', 2, '2017-04-20 19:45:25', 1, 2, 0),
(41, 'l.dergham@esi-sba.dz', 'c42ab3ef0b795ad1f8f700b3f38089b49247a7f1', '', 'DERGHAM', 'LAHCEN', '', 2, '2017-04-20 21:58:04', 1, 2, 0),
(42, 'a.mous@esi-sba.dz', '4fdb686469c87a3ad61a516908d9dd87e527c00f', '', 'LOKBANI', 'Chouaib', 'DOCTORAT', 1, '2017-04-20 22:50:28', 1, 1, 0),
(43, 't.lok@esi-sba.dz', 'da425b25504da7c005ea6f3d7b1b1c583fed70ed', '3435c378bb76d4357324dd7e69f3cd18', 'test', 'test', '', 2, '2017-04-29 00:45:23', 1, 2, 0),
(45, 'h.test@esi-sba.dz', '1509dcfc8446a904f6c6747d96ad0f60a02a48c0', '', 'wassim', 'hanana', '', 1, '2017-04-29 02:16:37', 1, 2, 0),
(47, 'ayma@esi-sba.dz', 'b01c81f1aa7ba92d8065ad2c7c1143ff99393210', '', 'Chouaib', 'ayman', '', 1, '2017-04-29 02:32:02', 1, 2, 0),
(48, 'd.dahman@esi-sba.dz', '$2y$10$f8ShacjbILONjyNoLHLR2ux0CfyqENZ.KmD3o1MgxI9/YrQCUiPwS', '97e8527feaf77a97fc38f34216141515', 'dahman', 'dahman', '', 2, '2017-04-29 02:59:24', 1, 2, 0),
(49, 's.salam@esi-sba.dz', '55490cd891a0e41ed5babc203cbb6a98c7424f02', '', 'salam', 'salam', '', 1, '2017-04-29 03:23:52', 1, 2, 0),
(52, 'a.belhadj@esi-sba.dz', '7ef4060115fc9ddcacf5f47b432b1ae52cf3b72b', '', 'ALI', 'BELHDAJ', '', 2, '2017-04-29 19:08:32', 1, 2, 0),
(55, 'hicham@esi-sba.dz', 'a25758bf71c5fb5e2e9e8eafd4d8ce2b836bff3d', '', 'hicham', 'hicham', '', 2, '2017-04-29 19:15:44', 1, 2, 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `biographie`
--
ALTER TABLE `biographie`
  ADD PRIMARY KEY (`BioId`),
  ADD KEY `BioUser` (`BioUser`);

--
-- Index pour la table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`ClasseId`);

--
-- Index pour la table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventId`);

--
-- Index pour la table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`NewsId`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`NotId`),
  ADD KEY `NotDestina` (`NotDestina`);

--
-- Index pour la table `study`
--
ALTER TABLE `study`
  ADD PRIMARY KEY (`StudyId`),
  ADD KEY `Level` (`Level`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD KEY `users_ibfk_1` (`Level`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `biographie`
--
ALTER TABLE `biographie`
  MODIFY `BioId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Biographie Id', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `classes`
--
ALTER TABLE `classes`
  MODIFY `ClasseId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'To Identifier', AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `events`
--
ALTER TABLE `events`
  MODIFY `EventId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'To Identifier Events', AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `news`
--
ALTER TABLE `news`
  MODIFY `NewsId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'To Identifier news', AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `NotId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'To Identifier Notifications', AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `study`
--
ALTER TABLE `study`
  MODIFY `StudyId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'To Identifier Study', AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'To Identifier users', AUTO_INCREMENT=56;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `biographie`
--
ALTER TABLE `biographie`
  ADD CONSTRAINT `biographie_ibfk_1` FOREIGN KEY (`BioUser`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`NotDestina`) REFERENCES `classes` (`ClasseId`);

--
-- Contraintes pour la table `study`
--
ALTER TABLE `study`
  ADD CONSTRAINT `study_ibfk_1` FOREIGN KEY (`Level`) REFERENCES `classes` (`ClasseId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`Level`) REFERENCES `classes` (`ClasseId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
